package com.varsitycollege.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "NETWIRK NUTIL IN MAIN";
        Fragment weatherFragment;
        Fragment tideFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        weatherFragment = new WeatherFragment();
        tideFragment = new TideFragment();

        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manger.beginTransaction();
        transaction.replace(R.id.weather_fragment_container, weatherFragment);
        transaction.replace(R.id.tide_fragment_container, tideFragment);
        transaction.commit();
    }
}